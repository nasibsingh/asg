const axios = require('axios');

const handler = (async (event) => {

try {
    // Make request to login API
    const loginResponse = await axios.request({
    url: 'http://localhost:8080/api/login',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: {
        email :"admin@usp.com",
        password :"cb1d5c3185360c68b180992c5f2f1dab"
    },
  });
  
  // Parse response from login API
  const loginResult = loginResponse.data;
  const token = loginResult.token;


  // Make request to survey API with bearer token
  const surveyResponse = await  axios.request({
    url: 'http://localhost:8080/api/cron/survey-report',
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  // Parse response from survey API
  const surveyResult = surveyResponse.data;

  
} catch (error) {
    console.log(error)
}
  
})();